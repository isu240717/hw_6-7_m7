package com.example.hw_1_7.doors

import androidx.lifecycle.ViewModel
import dagger.hilt.android.lifecycle.HiltViewModel

class DoorsViewModel:ViewModel() {
}